instructions_start = \
"""
Hello!
The commands are the following:
1. add: Add new registry
2. show: Show categories, cards, and last 3 transactions
3. see: See last X days transactions
4. rem: Remainder for the month
5. del: Delete a registry
6. addpast: Add new registry in the past
"""

instructions_error = \
"""
I don't understand the command
The commands are the following:
1. add: Add new registry
2. addpast: Add new registry in the past
3. see: See last X days transactions
4. rem: Remainder for the month
5. del: Delete a registry
"""